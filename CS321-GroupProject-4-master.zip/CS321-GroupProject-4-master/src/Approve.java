package src;
public class Approve{
    public static void main(String args[]) {
    }
}