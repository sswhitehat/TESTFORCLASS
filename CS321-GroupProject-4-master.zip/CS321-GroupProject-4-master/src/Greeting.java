package src;
public class Greeting {
    public Object getMessage(){
        return "Hello World!";
    }
}
