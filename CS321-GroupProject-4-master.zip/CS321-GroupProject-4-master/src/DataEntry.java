package src;
public class DataEntry {
    
    public static void main(String args[]) {
        System.out.println("Entering data! TODO");
        System.out.println("This is a new feature!");
    }

    public String enterData(){
        return "Entered data!";
    }
}
